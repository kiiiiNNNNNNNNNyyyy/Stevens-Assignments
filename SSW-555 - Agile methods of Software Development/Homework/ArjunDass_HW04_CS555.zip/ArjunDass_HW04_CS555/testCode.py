from unittest import TestCase
import parser
import gedcom

parsedData = gedcom.parse("sample.ged")
ind = parser.forIndividual(parsedData)
fam = parser.forFamilies(parsedData)

class TestAgeLessThan150_US7(TestCase):
    def test_ageLessThan150_US7_ageIsNone(self):
        self.assertIsNotNone(ind[0]['age'], "ERROR: Individual : US07: Age " + str(ind[0]['age']) + " Age cannot be None.")

    def test_ageLessThan150_US7_isInteger(self):
        self.assertEqual(type(ind[0]['age']),int, "ERROR: Individual : US07: Age " + str(ind[0]['age']) + "Age is not an Integer.")

    def test_ageLessThan150_US7_ageIsNegative(self):
        self.assertGreater(ind[0]['age'], 0, "ERROR: Individual: US07: Age " + str(ind[0]['age']) + " Age can't be negative.")

    def test_ageLessThan150_US7_ageIsFloat(self):
        self.assertNotEquals(type(ind[0]['age']), float, "ERROR: Individual: US07: Age " + str(ind[0]['age']) + " Age can't be float.")

    def test_ageLessThan150_US7_ReturnsFalse(self):
        self.assertFalse(parser.ageLessThan150_US7(ind), "ERROR: Individual: US07: Returns False, Function can't return False.")