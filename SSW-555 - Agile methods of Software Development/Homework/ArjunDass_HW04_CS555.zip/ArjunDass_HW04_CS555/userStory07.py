def ageLessThan150_US7(allPersons):
    for i in range(len(allPersons)):
        if allPersons[i]['age'] > 150:
            print "For ID "+allPersons[i]['id']+" Age gt 150 is not possible"
            return False