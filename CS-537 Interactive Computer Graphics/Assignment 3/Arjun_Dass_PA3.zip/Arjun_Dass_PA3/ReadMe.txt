
Submission Folder Contents:

Documentation:
- Documentation.pdf

Source Code:
- clipper.java
- clipTest.java
- extendedCanvas.java
- simpleCanvas.java

Output Images:
- Output.png

Project Folders:
- Arjun_Dass_PA3

Execution - Inorder to run my program, import the entire folder into eclipse or any other IDE and run the program.