How to run the Program

1.) Import the src folder into your IDE
2.) Add the attached Jama.jar as an external library to your src project's build path configuration.
3.) Run the program.