import java.awt.*;
import java.awt.event.*;

public class lineTest {

		static public void main(String[] args){

        simpleCanvas S = new simpleCanvas(600, 600);
        Rasterizer R = new Rasterizer (600);

        S.setColor (1.0f, 1.0f, 1.0f);
       
        S.setColor( 0.0f, 1.0f, 0.0f );
        R.drawLine( 80, 340, 220, 340, S );   // Horizontal left to right 
        R.drawLine( 40, 380, 80, 340, S );    // 315 degree slope        
        R.drawLine( 220, 340, 260, 380, S );  // 45 degree slope          
        R.drawLine( 260, 380, 260, 440, S );  // Vertical bottom to top
        R.drawLine( 260, 440, 180, 440, S );  // Horizontal right to left
        R.drawLine( 180, 440, 180, 400, S );
        R.drawLine( 180, 400, 220, 400, S );
        R.drawLine( 220, 400, 200, 380, S );
        R.drawLine( 200, 380, 100, 380, S );
        R.drawLine( 100, 380, 80, 400, S );
        R.drawLine( 80, 400, 80, 500, S );
        R.drawLine( 80, 500, 100, 520, S );
        R.drawLine( 100, 520, 200, 520, S );
        R.drawLine( 200, 520, 220, 500, S );
        R.drawLine( 220, 500, 220, 480, S );
        R.drawLine( 220, 480, 260, 480, S );
        R.drawLine( 260, 480, 260, 520, S );
        R.drawLine( 260, 520, 220, 560, S );  // 135 degree slope
        R.drawLine( 220, 560, 80, 560, S );
        R.drawLine( 80, 560, 40, 520, S );    // 225 degree slope
        R.drawLine( 40, 520, 40, 380, S );    // Vertical top to bottom

        // ######## The letter 'O' in orange ########
        S.setColor( 1.0f, 0.647f, 0.0f );
        
        R.drawLine( 420, 380, 480, 380, S );
        R.drawLine( 480, 380, 520, 420, S );
        R.drawLine( 520, 420, 520, 480, S );
        R.drawLine( 520, 480, 480, 520, S );
        R.drawLine( 480, 520, 420, 520, S );
        R.drawLine( 420, 520, 380, 480, S );
        R.drawLine( 380, 480, 380, 420, S );
        R.drawLine( 380, 420, 420, 380, S );
        
        R.drawLine( 393, 340, 515, 340, S );  // big O
        R.drawLine( 340, 518, 340, 395, S ); 
        R.drawLine( 393, 340, 340, 395, S ); 
        R.drawLine( 511, 560, 390, 560, S ); 
        R.drawLine( 390, 560, 340, 518, S ); 
        R.drawLine( 560, 390, 560, 511, S ); 
        R.drawLine( 560, 511, 511, 560, S ); 
        R.drawLine( 560, 400, 515, 340, S ); 
       
        //PRINTING MY INITIALS (AD)
        S.setColor( 0.0f, 1.0f, 1.0f );
        // Creating outer A
        R.drawLine( 49, 100, 135, 300, S );
        R.drawLine( 80, 100, 140, 250, S );
        R.drawLine( 139, 300, 235, 100, S );
        R.drawLine( 139, 250, 205, 100, S );
        
        // Creating inner A
        R.drawLine( 120, 200, 165, 200, S ); // horizontal
        R.drawLine( 115, 180, 175, 180, S ); // horizontal
        R.drawLine( 49, 100, 80, 100, S ); // horizontal
        R.drawLine( 215, 100, 240, 100, S ); 
        
        S.setColor( 1.0f, 0.2f, 0.65f );
        //Creatnig inner D
        R.drawLine( 420, 150, 480, 150, S );
        R.drawLine( 480, 150, 520, 190, S );
        R.drawLine( 520, 190, 520, 250, S );
        R.drawLine( 520, 250, 480, 290, S );
        R.drawLine( 480, 290, 420, 290, S );
        //R.drawLine( 420, 520, 380, 480, S );
        //R.drawLine( 380, 480, 380, 420, S );
        //R.drawLine( 380, 420, 420, 380, S );
        
        //creating outer D
        R.drawLine( 393, 110, 515, 110, S );  
        //R.drawLine( 340, 518, 340, 395, S ); 
        //R.drawLine( 393, 340, 340, 395, S ); 
        R.drawLine( 511, 330, 393, 330, S ); 
        //R.drawLine( 390, 560, 340, 518, S ); 
        R.drawLine( 560	, 160, 560, 275, S ); 
        R.drawLine( 560, 281, 511, 330, S ); 
        R.drawLine( 560, 190, 515, 110, S ); 
        R.drawLine(393, 107, 393, 330, S);
        R.drawLine(	420, 150, 420, 290, S);
        
        
        
         Frame f = new Frame( "Line Test" );
        f.add("Center", S);
        f.pack();
        f.setResizable (false);
        f.setVisible(true);

        f.addWindowListener( new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        } );

    }

}