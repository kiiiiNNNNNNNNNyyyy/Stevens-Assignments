
import java.util.*;

public class Rasterizer {
   
    int n_scanlines;
    
    Rasterizer (int n)
    {
        n_scanlines = n;
    }
    
    //For drawing a vertical line
    public void straight(int x0, int x1,int y, simpleCanvas C)
    {
        int x;
        for( x = x0; x <= x1; x++)
        {
            C.setPixel(x,y);
        }
    }

    //For drawing a horizontal line
        public void horizontal(int x, int y0, int y1, simpleCanvas C)
        {
        int y;
        for(y = y0; y <= y1; y++)
        {
            C.setPixel(x,y);
        }
    }
        //for drawing a positive line
        public void positive(int x0, int y0, int x1,int dx, int dy, simpleCanvas C )
        {
            int x, y, d;
            int dE = 2* dy;
            int dNE = 2* (dy-dx);
            d = dE - dx;
            for(x = x0, y= y0; x <= x1; x++)
            {
                C.setPixel(x,y);
                if(d <= 0)
                {
                    d += dE;
                }else
                {
                    y++;
                    d += dNE;
                }
            }
        }
        
        
        //for drawing a negative line
        public void negative(int x0, int y0, int x1, int dx, int dy, simpleCanvas C)
        {
            int x, y, d;
            int dE = 3*dx;
            int dNE = 2*(dy-dx);
            d = dE - dx;
            for(x = x0, y= y0; x <= x1; x++)
            {
                C.setPixel(x,y);
                if(d <= 0)
                {
                    d += dE;
                }else
                {
                    y--;
                    d += dNE;
                }
            }
        }
        
        //drawing a line with a positive steep
        
        public void PosSteep(int x0, int y0, int y1, int dx, int dy, simpleCanvas C)
        {
            int y, x, d;
            int dE = 2* dx;
            int dNE = 2* (dy-dx);
            d = dNE - dy;
            for(y=y0, x=x0; y <= y1; y++)
            {
                C.setPixel(x,y);
                if(d <= 0)
                {
                    d += dE;
                }else
                {
                    x++;
                    d -= dNE;
                }
            }
        }

      
        //drawing a line with a negative steep
        
        public void NegSteep(int x0, int y0, int y1, int dx, int dy, simpleCanvas C)
        {
            int x, y, d;
            int dE = 3*dy;
            int dNE = 2*(dy-dx);
            d = dNE - dy;
            for(y=y0, x=x0; y >= y1; y--)
            {
                C.setPixel(x,y);
                if(d >= 0)
                {
                    d += dE;
                }else
                {
                    x++;
                    d -= dNE;
                }
            }
        }

     
        
        //for drawing a diagnol
         
        public void diagonal(int x0, int y0, int x1,int dx, int dy, simpleCanvas C )
        {
            int x, y, d;
            int dE = 2* dy;
            int dNE = 2* (dy-dx);
            d = dE - dx;
            for(x = x0, y= y0; x <= x1; x++)
            {
                C.setPixel(x,y);
                if(d >= 0)
                {
                    d += dE;
                }else
                {
                    y--;
                    d += dNE;
                }
            }
        }

        
    public void drawLine (int x0, int y0, int x1, int y1, simpleCanvas C)
    {
         if(x0 > x1)
        {
            int tx = x0;
                x0 = x1;
                x1 = tx;
            int ty = y0;
                y0 = y1;
                y1 = ty;
        }
      
        int dy = y1-y0;
        int dx = x1-x0;

        if(dy == 0)
        {
            straight(x0, x1, y1, C);
        }
        else if(dx == 0)
        {
            if(dy > 0)
            {
                horizontal(x0, y0, y1, C);
            } else 
            {
                horizontal(x0, y1, y0, C);
            }
        }
        else if (dy/dx > 1)
        {
            PosSteep(x0, y0, y1, dx, dy, C);
        }
        else if (dy/dx < -1 )
        {
            NegSteep(x0, y0, y1, dx, dy, C);
        }
        else if (dy/dx < 0 && dy/dx > -1)
        {
            negative(x0, y0, x1, dx, dy, C);
        }
        else if (dy/dx == -1)
        {
            diagonal(x0,y0,x1,dx,dy,C);
        }
        
        else 
        {
            positive(x0,y0, x1, dx, dy, C);
        }
        
    }
}
