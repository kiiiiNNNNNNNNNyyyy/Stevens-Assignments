//
//  Rasterizer.java
//
// Created by Srinivas Sridharan on 2/10/17.
// Copyright 2017 Stevens Institute of Technology. All rights reserved.
//
//  Contributor:  Arjun Dass
//

///
// 
// This is a class that performas rasterization algorithms
//
///

import java.util.*;

public class Rasterizer {
    
    ///
    // number of scanlines
    ///

    int n_scanlines;
    
    ///
    // Constructor
    //
    // @param n - number of scanlines
    //
    ///

    Rasterizer (int n)
    {
        n_scanlines = n;
    }
    
    ///
    // Draw a filled polygon in the simpleCanvas C.
    //
    // The polygon has n distinct vertices. The 
    // coordinates of the vertices making up the polygon are stored in the 
    // x and y arrays.  The ith vertex will have coordinate  (x[i], y[i])
    //
    // You are to add the implementation here using only calls
    // to C.setPixel()
    ///

    public void drawPolygon(int n, int x[], int y[], simpleCanvas C) {
        // YOUR IMPLEMENTATION GOES HERE
    	int table[][] = new int[n][6];
        int abc[][] = new int[n][6];
        int position = 0;
        int array[][] = new int[1][1];
        int ymax, ymin;
        ymax = y[0];
        ymin = y[0];
        int flag[] = new int[10];

        int xmax1[] = new int[7];
        int xmin1[] = new int[7];
        xmax1[0] = x[0];
        xmin1[0] = x[0];
        for (int i = 1; i < n; i++) {
            if (y[i] > ymax) {
                ymax = y[i];
            }
            if (y[i] < ymin) {
                ymin = y[i];
            }
        }

        int sl = ymin;
        for (int i = 1; i < n; i++) {
            if (x[i] > xmax1[i - 1]) {
                xmax1[i - 1] = x[i];
            }
            if (x[i] < xmin1[i - 1]) {
                xmin1[i] = x[i];
            }
        }

        for (int i = 0; i < n - 1; i++) {

        	if (y[0] > y[n - 1]) {
            	
           	 table[n - 1][0] = y[n - 1];
                table[n - 1][1] = y[0];
                table[n - 1][2] = x[n - 1];
                table[n - 1][3] = x[n - 1] - x[0];
                table[n - 1][4] = y[n - 1] - y[0];
                table[n - 1][5] = 0;

           } else {
           	table[n - 1][0] = y[0];
               table[n - 1][1] = y[n - 1];
               table[n - 1][2] = x[0];
               table[n - 1][3] = x[0] - x[n - 1];
               table[n - 1][4] = y[0] - y[n - 1];
               table[n - 1][5] = 0;
              
           }
        	
            if (y[i] > y[i + 1]) {
            	
            	table[i][0] = y[i + 1];
                table[i][1] = y[i];
                table[i][2] = x[i + 1];
                table[i][3] = x[i + 1] - x[i];
                table[i][4] = y[i + 1] - y[i];
                table[i][5] = 0;

            } else {
            	table[i][0] = y[i];
                table[i][1] = y[i + 1];
                table[i][2] = x[i];
                table[i][3] = x[i] - x[i + 1];
                table[i][4] = y[i] - y[i + 1];
                table[i][5] = 0;
            }
        }

        while (sl < ymax) {
            for (int i = 0; i < n; i++) {
                if (table[i][0] == sl) {
                    abc[position] = table[i];
                    flag[position] = 1;
                    position++;
                } else {
                    flag[position] = 2;
                }
            }
            for (int i = 0; i < position; i++) {
                for (int j = 1; j < position - i; j++) {
                    if ((abc[j - 1][2] > abc[j][2]) && (flag[j - 1] == 1)) {
                        array[0] = abc[j - 1];
                        abc[j - 1] = abc[j];
                        abc[j] = array[0];
                    }
                }
            }
            for (int i = 0; i < position; i++) {
                if ((sl == abc[i][1]) && (flag[i] == 1)) {
                    if (flag[i + 1] == 1) {
                        for (int j = i; j < position - 1; j++) {
                            if ((flag[j + 1] == 1)) {
                                abc[j] = abc[j + 1];
                            }
                        }
                        position--;
                    } else {
                        position--;
                    }
                }
            }

            for (int j = 0; j < position - 1; j = j + 2) {
                for (int i = abc[0][2]; i <= abc[1][2]; i++) {
                    C.setPixel(i, sl);
                }
                for (int q = 0; q < 2; q++) {
                    int a = 0;
                    if (abc[q][4] != 0) {
                        a = (abc[q][3] + abc[q][5]) / abc[q][4];
                    }
                    int r = (abc[q][3] + abc[q][5]) - (a * abc[q][4]);
                    abc[q][2] = abc[q][2] + a;
                    abc[q][5] = r;
                }
            }
            sl++;
        }
    }
}