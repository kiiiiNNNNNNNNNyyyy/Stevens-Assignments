
import java.awt.*;
import java.nio.*;
import java.util.Vector;
import java.awt.event.*;
import javax.media.opengl.*;
import javax.media.opengl.awt.GLCanvas;
import java.io.*;

public class cgShape extends simpleShape
{
    public cgShape()
    {
    	
    }

    //this method take parameters for one side at a time and create one side.
    void TessallationForCube(float x, float y, float z, float sideLen, int subdivisions, int pos, char fixedCoord){
    	float newX,newY,newZ,newSideLen;
    	
    	//create side of cube where x is fixed coordinate
    	if( fixedCoord == 'x' ){
    		//adding triangles horizontally in z direction
    		//with increment in y after every z length is complete.
    		for( int i = 0 ; i < subdivisions; i++ ){
    			for( int j = 0; j < subdivisions; j++ ){
    				
    				newSideLen = sideLen/subdivisions;
    				//for side in positive x-axis
    				if( pos == 1){
    					newY = y + i*(sideLen/subdivisions);
        				newZ = z - j*(sideLen/subdivisions);
    					
    	    			addTriangle(x,newY,newZ, x,newY,newZ-newSideLen, x,newY+newSideLen,newZ-newSideLen);
    	    			addTriangle(x,newY,newZ, x,newY+newSideLen,newZ-newSideLen, x,newY+newSideLen,newZ);
    	    		}
    				//for side in -ve x-axis
    				else{
    	    			newY = y + i*(sideLen/subdivisions);
        				newZ = z + j*(sideLen/subdivisions);
    	    			
    	    			addTriangle(x,newY,newZ, x,newY,newZ+newSideLen, x,newY+newSideLen,newZ+newSideLen);
    	    			addTriangle(x,newY,newZ, x,newY+newSideLen,newZ+newSideLen, x,newY+newSideLen,newZ);
    	    		}
    			}
    		}
    	}
    	
    	//create side of cube where y is fixed coordinate
    	else if( fixedCoord == 'y'){
    		//adding triangles horizontally in x direction
    		//with increment in z after every x length is complete.
    		for( int i = 0 ; i < subdivisions; i++ ){
    			for( int j = 0; j < subdivisions; j++ ){

    				
    				newSideLen = sideLen/subdivisions;
    				//for side in positive y-axis
    				if( pos == 1){
        				newX = x + i*(sideLen/subdivisions);
        				newZ = z - j*(sideLen/subdivisions);
    					
    	    			addTriangle(newX,y,newZ, newX+newSideLen,y,newZ-newSideLen, newX,y,newZ-newSideLen);
    	    			addTriangle(newX,y,newZ, newX+newSideLen,y,newZ, newX+newSideLen,y,newZ-newSideLen);
    	    		}
    				//for side in -ve y-axis
    				else{
        				newX = x - i*(sideLen/subdivisions);
        				newZ = z - j*(sideLen/subdivisions);
    	    			
    	    			addTriangle(newX,y,newZ, newX-newSideLen,y,newZ-newSideLen, newX,y,newZ-newSideLen);
    	    			addTriangle(newX,y,newZ, newX-newSideLen,y,newZ, newX-newSideLen,y,newZ-newSideLen);
    	    		}
    			}
    		}
    	}
    	//create side of cube where z is fixed coordinate
    	else{
    		//adding triangles horizontally in x direction
    		//with increment in y after every x length is complete.
    		for( int i = 0 ; i < subdivisions; i++ ){
    			for( int j = 0; j < subdivisions; j++ ){
    				newSideLen = sideLen/subdivisions;
    				//for side in positive z-axis
    				if( pos == 1){
    					newX = x + j*(sideLen/subdivisions);
        				newY = y + i*(sideLen/subdivisions);
        				    					
    					addTriangle(newX,newY,z, newX+newSideLen,newY,z, newX+newSideLen,newY+newSideLen,z);
    	    			addTriangle(newX,newY,z, newX+newSideLen,newY+newSideLen,z, newX,newY+newSideLen,z);
    	    		}
    				//for side in -ve z-axis
    				else{
    	    			newX = x - j*(sideLen/subdivisions);
        				newY = y + i*(sideLen/subdivisions);
        				
    	    			addTriangle(newX,newY,z, newX-newSideLen,newY,z, newX-newSideLen,newY+newSideLen,z);
    	    			addTriangle(newX,newY,z, newX-newSideLen,newY+newSideLen,z, newX,newY+newSideLen,z);
    	    		}
    			}
    		}
    	}
    	
    	
    }
    
    /**
     * makeCube - Create a unit cube, centered at the origin, with a given
     * number of subdivisions in each direction on each face.
     *
     * @param subdivision - number of equal subdivisons to be made in each
     *        direction along each face
     *
     * Can only use calls to addTriangle()
     */
    public void makeCube(int subdivisions)
    {
        if( subdivisions < 1 )
            subdivisions = 1;

        // YOUR IMPLEMENTATION HERE
        float x,y,z,sideLen;
        int position; // 1 : front facing, 0: back facing
        char fixedCoord;
        sideLen = 1.0f;
        
        //drawing front side of the cube
        x = -0.5f;
        y = -0.5f;
        z = 0.5f;
        position = 1;//on positive z axis
        fixedCoord = 'z';
        TessallationForCube(x,y,z,sideLen,subdivisions,position,fixedCoord);
        
        //drawing back face of the cube
        x = 0.5f;
        y = -0.5f;
        z = -0.5f;
        position = 0;//on -ve z axis
        fixedCoord = 'z';
        TessallationForCube(x,y,z,sideLen,subdivisions,position,fixedCoord);
        
        //drawing right face of the cube
        x = 0.5f;
        y = -0.5f;
        z = 0.5f;
        position = 1;//on positive x axis
        fixedCoord = 'x';
        TessallationForCube(x,y,z,sideLen,subdivisions,position,fixedCoord);
        
        //drawing left face of the cube
        x = -0.5f;
        y = -0.5f;
        z = -0.5f;
        position = 0;//on -ve x axis
        fixedCoord = 'x';
        TessallationForCube(x,y,z,sideLen,subdivisions,position,fixedCoord);
        
        //drawing top face of the cube
        x = -0.5f;
        y = 0.5f;
        z = 0.5f;
        position = 1;//on positive y axis
        fixedCoord = 'y';
        TessallationForCube(x,y,z,sideLen,subdivisions,position,fixedCoord);
        
        //drawing bottom face of the cube
        x = 0.5f;
        y = -0.5f;
        z = 0.5f;
        position = 0;//on -ve y axis
        fixedCoord = 'y';
        TessallationForCube(x,y,z,sideLen,subdivisions,position,fixedCoord);
       
    }

    /**
     * makeCylinder - Create polygons for a cylinder with unit height, centered
     * at the origin, with separate number of radial subdivisions and height
     * subdivisions.
     *
     * @param radius - Radius of the base of the cylinder
     * @param radialDivision - number of subdivisions on the radial base
     * @param heightDivisions - number of subdivisions along the height
     *
     * Can only use calls to addTriangle()
     */
    public void makeCylinder (float radius, int radialDivisions, int heightDivisions)
    {
        if( radialDivisions < 3 )
            radialDivisions = 3;

        if( heightDivisions < 1 )
            heightDivisions = 1;
        
        final double fullAngle = 360;
        final double PI = 3.14159265f;
        
        //finding the central angle of each triangle in the base
        double central_angle = (fullAngle/radialDivisions)*(PI/180); // in radians
        
        float y = 0.5f;       
        
        // circumference coordinates
        float circ1X = radius;
        float circ1Z = 0f;
        
        float circ2X;
        float circ2Z;
        
        //finding height of each subdivision i.e. incement in y
        float newDivHeight = 1.0f/heightDivisions; //new height of each divisions
        
        //loop over radial divisions to finding next coordinates on the circumference
        for(int i = 0; i < radialDivisions; i++){
        	//getting next coordinates on circumference.
        	//formulae to find coordinates on circumference
        	// x = r*cos(alpha)
        	// z = r*sin(alpha)
        	circ2X = (float)(radius*Math.cos(central_angle*(i+1)));
        	circ2Z = (float)(radius*Math.sin(central_angle*(i+1)));
        	
        	
        	// drawing upper circle (upper base)
        	y = 0.5f;
        	addTriangle(0f,y,0f, circ2X,y,circ2Z, circ1X,y,circ1Z);
        	
        	// drawing lower circle (lower abse)
        	y = -0.5f;
        	addTriangle(0f,y,0f, circ1X,y,circ1Z, circ2X,y,circ2Z);
        	
        	
        	
        	//drawing curved surface
        	for(int j = 0; j < heightDivisions; j++){
        		
        		y = -0.5f + (newDivHeight)*j;
        		
        		addTriangle(circ2X,y,circ2Z, circ1X,y,circ1Z, circ1X,y+newDivHeight,circ1Z);
        		addTriangle(circ2X,y,circ2Z, circ1X,y+newDivHeight,circ1Z, circ2X,y+newDivHeight,circ2Z);
        	}
        	
        	//passing new found circumference coordinates to 
        	//old cirumference coordinates to use in next triangle drawing on base.
        	circ1X = circ2X;
        	circ1Z = circ2Z;
        }
        

       
    }

    /**
     * makeCone - Create polygons for a cone with unit height, centered at the
     * origin, with separate number of radial subdivisions and height
     * subdivisions.
     *
     * @param radius - Radius of the base of the cone
     * @param radialDivision - number of subdivisions on the radial base
     * @param heightDivisions - number of subdivisions along the height
     *
     * Can only use calls to addTriangle()
     */
    public void makeCone (float radius, int radialDivisions, int heightDivisions)
    {
        if( radialDivisions < 3 )
            radialDivisions = 3;

        if( heightDivisions < 1 )
            heightDivisions = 1;

        // YOUR IMPLEMENTATION HERE
        final double fullAngle = 360;
        final double PI = 3.14159265f;
        
        //finding central angle of the triangles of the base
        double central_angle = (fullAngle/radialDivisions)*(PI/180); // in radians
        
        float y = 0.5f;
        
        // circumference coordinates
        
        float circ1X = radius;
        float circ1Z = 0f;
        
        float circ2X;
        float circ2Z;
        
        //divinding the radius to get the 
        //decrease in x cordinate or in radius with 
        // as the height increases from bottom to up.
        float radiusDivLen = 0.5f/heightDivisions;
        
        //these slant coordinates are used to
        //draw curved surface of cone. these are
        //X coordinates of each four sided polygon
        //divided in two triangles and 1,2,3,4 denotes
        //X coordinates taken in clockwise order
        //where slant1X denotes bottom right X cordinate
        //of each four sided polygon.
        //in starting slant1X = circ1X and 
        //slant2X will be determined , slant3X will determined
        //in the loop  and slant4X is 
        //radiusDivLen minus circ1X in starting.
        
        float slant1X = circ1X;
        float slant2X;
        float slant3X;
        float slant4X = circ1X-radiusDivLen;
        
        //same explanation as for slantX , only slant4Z will have
        //same cordinate as circ1Z and changing along x in starting
        // only and no change along z.
        float slant1Z = circ1Z;
        float slant2Z;
        float slant3Z;
        float slant4Z = circ1Z;
        
        float newDivHeight = 1.0f/heightDivisions; //new height of each divisions
        
        
        //looping through the radial divisions 
        for(int i = 0; i < radialDivisions; i++){
        	
        	//finding new circumference coordinates
        	circ2X = (float)(radius*Math.cos(central_angle*(i+1)));
        	circ2Z = (float)(radius*Math.sin(central_angle*(i+1)));
        	
        	// drawing lower circle (lower abse)
        	y = -0.5f;
        	addTriangle(0f,y,0f, circ1X,y,circ1Z, circ2X,y,circ2Z);
        	
        	
        	
        	//drawing curved surface
        	slant1X = circ1X;
        	slant1Z = circ1Z;
        	slant2X = circ2X;
        	slant2Z = circ2Z;
        	for(int j = 0; j < heightDivisions; j++){
        		//circumference coordinates of the new smaller circle which can be seen as 
        		//new base. then drawing tesselated four sided polygon using cicumference
        		//coordinates of new base and old base.And these coordinates are called as
        		//slant coordinates
        		slant3X = (float)((radius-radiusDivLen*(j+1))*Math.cos(central_angle*(i+1)));
        		slant3Z = (float)((radius-radiusDivLen*(j+1))*Math.sin(central_angle*(i+1)));
        		slant4X = (float)((radius-radiusDivLen*(j+1))*Math.cos(central_angle*(i)));
        		slant4Z = (float)((radius-radiusDivLen*(j+1))*Math.sin(central_angle*(i)));
        		y = -0.5f + (newDivHeight)*j;
        		
        		addTriangle(slant2X,y,slant2Z, slant1X,y,slant1Z, slant4X,y+newDivHeight,slant4Z);
        		addTriangle(slant2X,y,slant2Z, slant4X,y+newDivHeight,slant4Z, slant3X,y+newDivHeight,slant3Z);
        		
        		//passing new slant(new base) coordinates as old coordinates
        		slant1X = slant4X;
        		slant2X = slant3X;
        		slant1Z = slant4Z;
        		slant2Z = slant3Z;
        	}
        	
        	circ1X = circ2X;
        	circ1Z = circ2Z;
        }
    }
    
	public class points{ 
        float x,y,z;
        
        public points(float x1, float y1,float z1){
            setx(x1);
            sety(y1);
            setz(z1);
            
        }
        public points() {
			
		}
		
       
        public void copy(points a, points b ) {
            a.x = b.x;
            a.y = b.y;
            a.z = b.z;
        }
        
        
        public void setx(float x1) {
            
            x=x1;
        }
        
        public float getx() {
            
            return x;
        }
        
        public void sety(float y1) {
            y=y1;
        }
        
        public float gety() {
            return y;
        }
        public void setz(float z1) {
            z=z1;
        }
        
        public float getz() {
            return z;
        }
        
    }
    
	   void norm(points a ) {
	        float s = (float) (1.0f / Math.sqrt(a.getx() * a.getx() + a.gety() * a.gety() + a.getz() * a.getz()));
	        a.setx( a.getx()*s); a.sety( a.gety()*s);a.setz( a.getz()*s);
	        a.setx(a.getx()*0.5f); a.sety(a.gety()*0.5f); a.setz(a.getz()*0.5f);
	        
	    }
	    
	    class Triangle{
	        points p1;
	        points p2;
	        points p3;
	        
	        Triangle(points x1, points x2, points x3) {
	            p1 = x1;
	            p2 = x2;
	            p3 = x3;
	        }
	        
			public Triangle() {
				
			}
	    };
	    
	    points calculatemidpoint(points a,points b){
	        points c = new points();
	        c.setx((a.getx() + b.getx())*0.5f);
	        c.sety((a.gety() + b.gety())*0.5f);
	        c.setz((a.getz() + b.getz())*0.5f);
	        
	        return c;
	    }

	
	//same comments goes for this method as makeSphereOddStacks();
	//except here middle is not being drawn separatly.
	    public void makeSphere(float radius, int slices, int stacks){
	    	Vector<Triangle> tri = new Vector<Triangle>();
	        Vector<Triangle> triangle_1 = new Vector<Triangle>();
	        
	        float a = (float) (2.0f / ( 1.0f + Math.sqrt(5.0f) ));
	        points v0 = new points( 0.0f,  a, -1.0f);
	       
	        points v1= new points(-a,  1.0f,  0.0f);
	        points v2= new points( a,  1.0f,  0.0f);
	        points v3= new points( 0.0f,  a,  1.0f);
	        points v4= new points(-1.0f,  0.0f,  a);
	        points v5= new points( 0.0f, -a,  1.0f);
	        points v6= new points( 1.0f,  0.0f,  a);
	        points v7= new points( 1.0f,  0.0f, -a);
	        points v8= new points( 0.0f, -a, -1.0f);
	        points v9= new points(-1.0f,  0.0f, -a);
	        points v10=new points(-a, -1.0f, 0.0f);
	        points v11= new points( a, -1.0f, 0.0f);
	        
	        norm(v0);norm(v1);norm(v2);norm(v3);norm(v4);norm(v5);norm(v6);norm(v7);
	        norm(v8);norm(v9);norm(v10);norm(v11);
	       
	        
	        
	        Triangle t0=new Triangle(v0, v1, v2 );			
	    	Triangle t1=new Triangle(v3, v2, v1 );			
	    	Triangle t2= new Triangle(v3, v4, v5 );			
	    	Triangle t3=new Triangle(v3, v5, v6 );
	    	Triangle t4=new Triangle(v0, v7, v8 );
	    	Triangle t5=new Triangle(v0, v8, v9);				
	    	Triangle t6=new Triangle(v5, v10, v11 );
	    	Triangle t7=new Triangle(v8, v11, v10 );
	    	Triangle t8=new Triangle(v1, v9, v4 );
	    	Triangle t9=new Triangle(v10, v4, v9 );
	    	Triangle t10=new Triangle(v2, v6, v7 );				
	    	Triangle t11=new Triangle(v11, v7, v6 );
	    	Triangle t12=new Triangle(v3, v1, v4 );
	    	Triangle t13=new Triangle(v3, v6, v2 );
	    	Triangle t14=new Triangle(v0, v9, v1 );
	    	Triangle t15=new Triangle(v0, v2, v7 );				
	    	Triangle t16=new Triangle(v8, v10, v9 );
	    	Triangle t17=new Triangle(v8, v7, v11 );
	    	Triangle t18=new Triangle(v5, v4, v10 );
	    	Triangle t19=new Triangle(v5, v11, v6 );
	    	
	    	

	    	tri.addElement(t0);tri.addElement(t1);tri.addElement(t2);tri.addElement(t3);tri.addElement(t4);tri.addElement(t5);tri.addElement(t6);
	    	tri.addElement(t7);tri.addElement(t8);tri.addElement(t9);tri.addElement(t10);tri.addElement(t11);
	    	tri.addElement(t12);tri.addElement(t13);tri.addElement(t14);tri.addElement(t15);tri.addElement(t16);
	    	tri.addElement(t17);tri.addElement(t18);tri.addElement(t19);
	    	
	        
	    	for(int j=1;j<=slices;j++){
	    		if(slices==1){
	    			for(int i=0;i<tri.size();i++) {
	    				addTriangle(tri.elementAt(i).p1.x,tri.elementAt(i).p1.y,tri.elementAt(i).p1.z,
	                                tri.elementAt(i).p2.x,tri.elementAt(i).p2.y,tri.elementAt(i).p2.z,tri.elementAt(i).p3.x,
	                                tri.elementAt(i).p3.y,tri.elementAt(i).p3.z);
	                }}
	    		else{
	    			for(int i=0;i<tri.size();i++){
	    				points mp1p2 = calculatemidpoint(tri.elementAt(i).p1,tri.elementAt(i).p2);	//calculate midpoints
	    				points mp1p3 = calculatemidpoint(tri.elementAt(i).p1,tri.elementAt(i).p3);	
	    				points mp2p3 = calculatemidpoint(tri.elementAt(i).p2,tri.elementAt(i).p3);
	                    
	    				Triangle T1=new Triangle(tri.elementAt(i).p1, mp1p2, mp1p3 );
	    				triangle_1.addElement(T1);
	    				Triangle T2=new Triangle(mp1p2, tri.elementAt(i).p2, mp2p3 );
	    				triangle_1.addElement(T2);
	    				Triangle T3=new Triangle(mp2p3, tri.elementAt(i).p3, mp1p3 );
	    				triangle_1.addElement(T3);
	    				Triangle T4=new Triangle(mp1p2, mp2p3, mp1p3 );
	    				triangle_1.addElement(T4);
	    			}
	                
	    			
	    		}
	    		
	    		tri.clear();
	    		for(int k=0;k<triangle_1.size();k++)
	    			tri.addElement(triangle_1.elementAt(k));
	            
	    		for(int l=0;l<triangle_1.size();l++)
	    			triangle_1.removeElementAt(l);
	            
	        }
	    	for(int i=0;i<tri.size();i++){		
	            norm(tri.elementAt(i).p1);
	            norm(tri.elementAt(i).p2);
	            norm(tri.elementAt(i).p3);
	            addTriangle(tri.elementAt(i).p1.x,tri.elementAt(i).p1.y,tri.elementAt(i).p1.z,tri.elementAt(i).p2.x,tri.elementAt(i).p2.y,tri.elementAt(i).p2.z,tri.elementAt(i).p3.x,
	                        tri.elementAt(i).p3.y,tri.elementAt(i).p3.z);
	        }
	        
	    }
    
   
}